package com.kareem.noyaapp.noya_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
