// ignore_for_file: prefer_single_quotes
class AssetsManager {
  AssetsManager._();
  
  static const String imagesLogo = "assets/images/logo.jpg";

  static const String imagesNotFoundImage = "assets/images/NotFoundImage.png";
}

